package com.tutorias.cibertec.persistence.entity;

public class UsuarioEntity {



}
