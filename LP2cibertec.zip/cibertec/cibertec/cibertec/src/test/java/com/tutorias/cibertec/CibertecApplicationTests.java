package com.tutorias.cibertec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CibertecApplicationTests {

	@Test
	void contextLoads() {
	}

}
